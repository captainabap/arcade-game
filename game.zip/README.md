Game "Collect the gemstones"
============================

1. Installation 

Unpack the file game.zip in a directory. 

2. How to play

Open the index.html file in the browser by doubleclicking. 

You can move the Player with the arrow keys in the field. 
Avoid the bugs and collect as much gemstones as possible. Hurry up, because the beetles speed up. 

Have Fun! 
